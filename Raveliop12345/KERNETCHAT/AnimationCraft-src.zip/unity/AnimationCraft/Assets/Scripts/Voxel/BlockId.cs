namespace AnimationCraft.Voxel
{
    public enum BlockId : byte
    {
        Air = 0,
        Bedrock = 1,
        Stone = 2,
        Dirt = 3,
        Grass = 4,
        Sand = 5
    }
}
