namespace AnimationCraft.Core
{
    public static class WorldSession
    {
        public static string WorldId = "AnimationCraft-World";
        public static int Seed = 0;
        public static int ViewRadius = Constants.DefaultViewRadius;
    }
}
